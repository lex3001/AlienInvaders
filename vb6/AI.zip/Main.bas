Attribute VB_Name = "modMain"
Option Explicit

'if this is set, any loop should exit
Global gbErrorFlag As Boolean

Global Const SCREENWIDTH% = 640
Global Const SCREENHEIGHT% = 480


Public Declare Function GenericCallBack Lib "Callback\Callback.dll" (ByVal fPtr As Long, ByVal arg1 As Long, ByVal arg2 As Long, ByVal arg3 As Long, ByVal arg4 As Long) As Long
Public Declare Sub SimpleCallBack Lib "Callback\Callback.dll" (ByVal fPtr As Long)

Sub Initialize()
    gbErrorFlag = False
    On Error GoTo Initialize_ErrorHandler
    
    'initialize VB's random number generator
    Randomize
    
    'load the form that we will use for DirectX
    Load frmDDForm
    
    'Init other modules
    GUID_Initialize
    GameUtils_Initialize
    DirectX_Initialize
    
    Exit Sub

Initialize_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Initialize"
    Exit Sub
End Sub

Sub Main()
    On Error GoTo Main_ErrorHandler
    
    Initialize
    
    'Hide mouse
    ShowCursor 0
    
    Do
        If gbErrorFlag Then Exit Do
        GameMenu_Start
        If (isTimeToPlay()) Then
            GamePlay_Start
        End If
    Loop While Not isTimeToQuit()

    Terminate
    Exit Sub

Main_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Main"
    Terminate
    Exit Sub
End Sub

Sub Terminate()
    DirectX_Terminate
    GameUtils_Terminate
    
    'Redisplay mouse
    ShowCursor 1
    
    On Error Resume Next
    Unload frmDDForm
    On Error GoTo 0
    
    'End
End Sub

Sub DirectX_Terminate()
    Call DirectDraw_Terminate
    Call DirectSound_Terminate
    Call DirectInput_Terminate
End Sub

Sub DirectX_Initialize()
    Dim lbOk As Boolean
    
    '====== DIRECT SOUND ======
    'Initialize DirectSound
    lbOk = DirectSound_Initialize()
    If Not lbOk Then Exit Sub

    'Set DirectSound Cooperative Level
    lbOk = DirectSound_SetCooperativeLevel(frmDDForm, DSSCL_NORMAL)
    If Not lbOk Then Exit Sub

    '====== DIRECT DRAW ======
    'Initialize DirectDraw
    lbOk = DirectDraw_Initialize()
    If Not lbOk Then Exit Sub

    'Set DirectDraw Cooperative Level
    lbOk = DirectDraw_SetCooperativeLevel(frmDDForm, DDSCL_EXCLUSIVE Or DDSCL_FULLSCREEN)
    If Not lbOk Then Exit Sub

    'Set DirectDraw Display Mode
    lbOk = DirectDraw_SetDisplayMode(SCREENWIDTH, SCREENHEIGHT, 8)
    If Not lbOk Then Exit Sub

    'Create DirectDraw Flipping Buffers
    lbOk = DirectDraw_CreateFlippingBuffers()
    If Not lbOk Then Exit Sub

    '====== DIRECT INPUT ======
    'Initialize DirectInput
    lbOk = DirectInput_Initialize()
    If Not lbOk Then Exit Sub

    'Init for keyboard input
    lbOk = DirectInput_SetupKeyboard(frmDDForm)
    If Not lbOk Then Exit Sub

End Sub

Sub HandleError(rvNum, rvDesc, rvDLL, rvSource, rsWhere As String, _
                                Optional rvMoreInfo As Variant)
    On Error GoTo HandleError_ErrorHandler
    
    Dim liMsg As String
    liMsg = Now() & ": *** ERROR *** in " & rsWhere & ": " & vbCrLf & _
        "  Number: " & rvNum & vbCrLf & _
        "  Description: " & rvDesc & vbCrLf & _
        "  LastDllError: " & rvDLL & vbCrLf & _
        "  Source: " & rvSource & vbCrLf
    
    If Not IsMissing(rvMoreInfo) Then
        liMsg = liMsg & rvMoreInfo
    End If
    
    'only show msgbox first time
    If Not gbErrorFlag Then
        On Error Resume Next
        DebugPrint liMsg
        On Error GoTo HandleError_ErrorHandler
    End If
    
    ShowCursor 1
    MsgBox liMsg
    ShowCursor 0
    gbErrorFlag = True
    Exit Sub

HandleError_ErrorHandler:
    gbErrorFlag = True
    On Error GoTo 0
    Exit Sub
End Sub
