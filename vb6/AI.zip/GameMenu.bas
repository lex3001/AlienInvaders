Attribute VB_Name = "modGameMenu"
Option Explicit

Private count As Integer

'Loop control / Game control
Private mbQuit As Boolean
Private mbPlay As Boolean

'Descriptor for DirectDraw special blitting abilitiy
Private mDDBLTFX As DDBLTFX

Public Sub GameMenu_Start()
    On Error GoTo GameMenu_Start_ErrorHandler
    mbQuit = False
    mbPlay = False
    
    'Menu Loop
    Do
        If gbErrorFlag Then Exit Do
        GameMenu_Draw
        DirectDraw_Flip
        DirectInput_GetKeyboardState
        GameMenu_CheckInput
        DoEvents
    Loop While Not (mbQuit Or mbPlay)
    
    Exit Sub
    
GameMenu_Start_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "GameMenu_Start"
End Sub

Public Function isTimeToQuit() As Boolean
    isTimeToQuit = mbQuit
End Function

Public Function isTimeToPlay() As Boolean
    isTimeToPlay = mbPlay
End Function

' CallBack by: CallWindowProc

Public Sub GameMenu_CheckInput()
    If DirectInput_IsKeyDown(Directx.DIK_ESCAPE) Then
        mbQuit = True
    ElseIf DirectInput_IsKeyDown(Directx.DIK_RETURN) Then
        mbPlay = True
    End If
End Sub

Private Sub GameMenu_Draw()
    On Error GoTo GameMenu_Draw_ErrorHandler
    
    'Clear back buffer (fill with black)
    With mDDBLTFX
        .dwSize = Len(mDDBLTFX)
        .dwFillColor = RGB(0, 0, 0)
    End With
    gDDSBack.Blt ByVal 0&, Nothing, ByVal 0&, DDBLT_COLORFILL Or DDBLT_WAIT, mDDBLTFX

    'Draw some text
    Dim llHdc As Long
    Call gDDSBack.GetDC(llHdc)

    Dim lsMsg As String
    Dim lMsgSize As Size
    Call SetBkColor(llHdc, RGB(0, 0, 0))
    Call SetTextColor(llHdc, RGB(0, 0, 255))
'    Call SetTextColor(llHdc, RGB(Rnd * 255, Rnd * 255, Rnd * 255))

    lsMsg = "ALIEN INVADERS"
    Call GetTextExtentPoint32(llHdc, lsMsg, Len(lsMsg), lMsgSize)
    Call TextOut(llHdc, (SCREENWIDTH - lMsgSize.cx) / 2, (SCREENHEIGHT / 2) - lMsgSize.cy - 9, lsMsg, Len(lsMsg))

    Call SetTextColor(llHdc, RGB(0, 0, 255))
    lsMsg = "<esc>=quit, <enter>=play"
    Call GetTextExtentPoint32(llHdc, lsMsg, Len(lsMsg), lMsgSize)
    Call TextOut(llHdc, (SCREENWIDTH - lMsgSize.cx) / 2, (SCREENHEIGHT / 2) - lMsgSize.cy + 7, lsMsg, Len(lsMsg))

    Call gDDSBack.ReleaseDC(llHdc)
    
    Exit Sub
    
GameMenu_Draw_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "GameMenu_Draw"
End Sub
