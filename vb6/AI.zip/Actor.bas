Attribute VB_Name = "modActor"
Option Explicit

Global Const giDONT_MARCH% = -1

Type ActorMover
    'Properties
    iX As Integer
    iY As Integer
    iVelocity As Integer
    iDirection As Integer
    bStopAtBorder As Boolean
    bReverseAtBorder As Boolean
    iMarchingDistance As Integer  'or DONT_MARCH
    'State
    iLastX As Integer
    iLastY As Integer
    bIsOffScreenX As Boolean
    bIsOffScreenY As Boolean
    bIsOffScreen As Boolean
    bIsAtXBorder As Boolean
    bIsAtYBorder As Boolean
    bIsAtBorder As Boolean
    iMarched As Integer
    bFirstMove As Boolean
End Type

Type ActorDrawer
    'Properties
    ddsBitMapSurface As IDirectDrawSurface2
    iFrameSizeX As Integer
    iFrameSizeY As Integer
    iWidthInFrames As Integer
    iStartFrame As Integer
    iNumFrames As Integer
    iNextStartFrame As Integer
    iNextNumFrames As Integer
    bAutoSwitchToNextSequence As Boolean
    iFramesPerSecond As Integer
    iTicksPerFrame As Integer
    bLoopAnimation As Boolean
    'State
    iCurrentFrameInSequence As Integer
    bIsAnimationDone As Boolean
End Type

Type Actor
    iXSize As Integer
    iYSize As Integer
    iXCollisionBoxOffset As Integer
    iYCollisionBoxOffset As Integer
    iXCollisionBoxSize As Integer
    iYCollisionBoxSize As Integer
    bExploding As Boolean
    iState As Integer
    amMover As ActorMover
    adDrawer As ActorDrawer
End Type

Type PlayerGuns
    iMaxOnScreen As Integer
    lRechargeTime As Long
    lTicksSinceLastShot As Long
    bShotReady As Boolean
End Type

'
'============= ActorMover_Move =============
'
'
'Direction is in degrees
'Velocity is in pixels/second
'rgGame.TicksPassed is milliseconds
'Marching means going back and forth in a line over a specified distance
Public Sub ActorMover_Move(raActor As Actor, rgGame As Game)
    'Pixels to move
    Dim ldPixels As Double
    'X,Y factor (-1.0 to 1.0) in movement
    Dim ldXInc As Double
    Dim ldYInc As Double
    'If direction should reverse
    Dim lbReverse As Boolean
    
    With raActor.amMover
        'Store last position
        .iLastX = .iX
        .iLastY = .iY
        
        'Clear reverse flag
        lbReverse = False
        
        'Determine X,Y factor from direction angle (degrees)
        Call GetXYIncFromAngle(.iDirection, ldXInc, ldYInc)
        'Determine distance to move in pixels
        ldPixels = CDbl(.iVelocity * rgGame.lTicksPassed) / 1000
        
        'See if we are marching
        If .iMarchingDistance > 0 Then
            'If we are marching, are we go to march to far?
            If ((.iMarched + ldPixels) > .iMarchingDistance) Then
                'Adjust distance so we do not march to far, and reverse (later)
                ldPixels = .iMarchingDistance - .iMarched
                lbReverse = True
            End If
            'add distance to distance marched so far
            .iMarched = .iMarched + ldPixels
        End If
        
        'Calculate new X and Y positions
        .iX = .iX + (ldPixels * ldXInc)
        .iY = .iY + (ldPixels * ldYInc)
        
        'clear border flags
        .bIsAtXBorder = False
        .bIsAtYBorder = False
        .bIsOffScreenX = False
        .bIsOffScreenY = False
        
        'see if we are going to go off the playfield to the right
        If ((.iX + raActor.iXSize) > rgGame.iPlayWidth) Then
            'We are partially or fully off the playfield - so we stop or reverse?
            If .bReverseAtBorder Or .bStopAtBorder Then
                'WIP: Hmm, shouldn't we check this and then adjust distance afterwords?? or decrement Y same way?
                'don't go off- go to the edge
                .iX = rgGame.iPlayWidth - raActor.iXSize
                .bIsAtXBorder = True
                If .bReverseAtBorder Then lbReverse = True
            Else
                If (.iX > rgGame.iPlayWidth) Then .bIsOffScreenX = True
            End If
        'see if we are going to go off the playfield to the left
        ElseIf (.iX < 0) Then
            If .bReverseAtBorder Or .bStopAtBorder Then
                .iX = 0
                .bIsAtXBorder = True
                If .bReverseAtBorder Then lbReverse = True
            Else
                If (.iX + raActor.iXSize < 0) Then .bIsOffScreenX = True
            End If
        End If
        
        'see if we are going to go off the playfield to the bottom
        If ((.iY + raActor.iYSize) > rgGame.iPlayHeight) Then
            If .bReverseAtBorder Or .bStopAtBorder Then
                .iY = rgGame.iPlayHeight - raActor.iYSize
                .bIsAtYBorder = True
                If .bReverseAtBorder Then lbReverse = True
            Else
                If (.iY > rgGame.iPlayHeight) Then .bIsOffScreenY = True
            End If
        'see if we are going to go off the playfield to the top
        ElseIf (.iY < 0) Then
            If .bReverseAtBorder Or .bStopAtBorder Then
                .iY = 0
                .bIsAtYBorder = True
                If .bReverseAtBorder Then lbReverse = True
            Else
                If (.iY + raActor.iYSize) Then .bIsOffScreenY = True
            End If
        End If
        
        If lbReverse Then
            .iDirection = .iDirection + 180
            .iMarched = 0
        End If
    
        .bIsOffScreen = .bIsOffScreenX Or .bIsOffScreenY
        .bIsAtBorder = .bIsAtXBorder Or .bIsAtYBorder
        
    End With
End Sub

'
'============= ActorDrawer_Draw =============
'
'
Public Sub ActorDrawer_Draw(raActor As Actor, rgGame As Game)
    On Error GoTo ActorDrawer_Draw_ErrorHandler
    
    Dim RS As RECT
    Dim RD As RECT
    Dim DXFX As DDBLTFX
    
    Dim liFrameOffsetX As Integer
    Dim liFrameOffsetY As Integer
    Dim liClippedWidth As Integer
    Dim liClippedHeight As Integer
    Dim liFrameNumber As Integer
    Dim liBitMapOffsetX As Integer
    Dim liBitMapOffsetY As Integer
    
    With raActor.adDrawer
        'first part handles off the screen to the left, second normal, third off the screen to the right
        liClippedWidth = MinOf(MinOf(rgGame.iPlayWidth - raActor.amMover.iX, raActor.iXSize), _
                raActor.amMover.iX + raActor.iXSize)
        liClippedHeight = MinOf(MinOf(rgGame.iPlayHeight - raActor.amMover.iY, raActor.iYSize), _
                raActor.amMover.iY + raActor.iYSize)
        
        
        If (liClippedWidth <= 0) Or (liClippedHeight <= 0) Then
            Exit Sub
        End If
        
        liFrameNumber = .iCurrentFrameInSequence + .iStartFrame
        liFrameOffsetX = (liFrameNumber Mod .iWidthInFrames) * .iFrameSizeX
        liFrameOffsetY = Int(liFrameNumber / .iWidthInFrames) * .iFrameSizeY
        
        liBitMapOffsetX = Abs(MinOf(raActor.amMover.iX, 0))
        RS.Left = liBitMapOffsetX + liFrameOffsetX
        RS.Right = liClippedWidth + RS.Left
        liBitMapOffsetY = Abs(MinOf(raActor.amMover.iY, 0))
        RS.Top = liBitMapOffsetY + liFrameOffsetY
        RS.Bottom = liClippedHeight + RS.Top
        
        RD.Left = rgGame.iPlayXOffset + raActor.amMover.iX + liBitMapOffsetX
        RD.Right = RD.Left + liClippedWidth
        RD.Top = rgGame.iPlayYOffset + raActor.amMover.iY + liBitMapOffsetY
        RD.Bottom = RD.Top + liClippedHeight
        
        DXFX.dwSize = Len(DXFX)
        DXFX.ddckSrcColorkey.dwColorSpaceHighValue = 0
        DXFX.ddckSrcColorkey.dwColorSpaceLowValue = 0
        
        If (.iCurrentFrameInSequence + 1) >= .iNumFrames Then
            If .bAutoSwitchToNextSequence Then
                .bAutoSwitchToNextSequence = False
                .iStartFrame = .iNextStartFrame
                .iNumFrames = .iNextNumFrames
            Else
                .bIsAnimationDone = True
            End If
            If .bLoopAnimation Then
                .iCurrentFrameInSequence = 0
                .bIsAnimationDone = False
            End If
        Else
            .iCurrentFrameInSequence = .iCurrentFrameInSequence + 1
        End If
    
        rgGame.ddsBackBufferSurface.Blt RD, .ddsBitMapSurface, _
                RS, DDBLT_KEYSRCOVERRIDE, DXFX
    End With
    Exit Sub

ActorDrawer_Draw_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "ActorDrawer_Draw", _
        "  X,Y = " & raActor.amMover.iX & "," & raActor.amMover.iY & vbCrLf & _
        "  RS.Left = " & RS.Left & vbCrLf & _
        "  RS.Right = " & RS.Right & vbCrLf & _
        "  RS.Top = " & RS.Top & vbCrLf & _
        "  RS.Bottom = " & RS.Bottom & vbCrLf & _
        "  RD.Left = " & RD.Left & vbCrLf & _
        "  RD.Right = " & RD.Right & vbCrLf & _
        "  RD.Top = " & RD.Top & vbCrLf & _
        "  RD.Bottom = " & RD.Bottom & vbCrLf
    Exit Sub
End Sub

Public Function Actor_GetPan(raActor As Actor, rgGame As Game) As Double
    Dim liX As Integer
    Dim liPWFactor As Integer
    liPWFactor = rgGame.iPlayWidth / 2
    liX = raActor.amMover.iX + (raActor.iXSize / 2)
    If (liX < 0) Then
        Actor_GetPan = -1#
    ElseIf (liX > rgGame.iPlayWidth) Then
        Actor_GetPan = 1#
    Else
        Actor_GetPan = (liX - liPWFactor) / liPWFactor
    End If
End Function

Function Actor_DetectCollision(raActor1 As Actor, raActor2 As Actor) As Boolean
    Dim liX1 As Integer
    Dim liY1 As Integer
    Dim liX2 As Integer
    Dim liY2 As Integer
    Dim lbCollision As Boolean
    
    lbCollision = False
    liX1 = raActor1.amMover.iX + raActor1.iXCollisionBoxOffset
    liY1 = raActor1.amMover.iY + raActor1.iYCollisionBoxOffset
    liX2 = raActor2.amMover.iX + raActor2.iXCollisionBoxOffset
    liY2 = raActor2.amMover.iY + raActor2.iYCollisionBoxOffset
    If ((liY1 + raActor1.iYCollisionBoxSize) >= liY2) And _
            (liY1 < (liY2 + raActor2.iYCollisionBoxSize)) Then
        If ((liX1 + raActor1.iXCollisionBoxSize) >= liX2) And _
                (liX1 < (liX2 + raActor2.iXCollisionBoxSize)) Then
            'BANG!
            lbCollision = True
        End If
    End If
    
    Actor_DetectCollision = lbCollision
End Function

Public Sub PlayerGuns_UpdateState(rpgPlayerGuns As PlayerGuns, rgGame As Game)
    With rpgPlayerGuns
        If Not .bShotReady Then
            .lTicksSinceLastShot = .lTicksSinceLastShot + rgGame.lTicksPassed
            If .lTicksSinceLastShot >= .lRechargeTime Then
                .bShotReady = True
                '.lTicksSinceLastShot = .lTicksSinceLastShot - .lRechargeTime
                .lTicksSinceLastShot = 0
            End If
        End If
    End With
End Sub

