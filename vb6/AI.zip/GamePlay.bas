Attribute VB_Name = "modGamePlay"
Option Explicit

Global Const giMAX_MISSLES% = 10

'So we know when to quit
Dim mbQuit As Boolean

'Used to pass game context to other modules
Dim mgGame As Game

'Used to keep time
Dim mlTickCount As Long
Dim mlLastTickCount As Long
Dim mlFirstTickCount As Long
Dim mlTicksPassed As Long
Dim mdFrames As Double
Dim mdAvgFramesPerSecond As Double

'Pen used for drawing lines
Dim mlHPen As Long

'Descriptor for DD special blitting abilitiy
Private mddfxPaintBlack As DDBLTFX
    
    
Public Sub GamePlay_Start()
    On Error GoTo GamePlay_Start_ErrorHandler
    mbQuit = False
    
    Call GamePlay_Initialize
    
    Do
        Call Level1_Initialize(mgGame)
        If gbErrorFlag Then
            Call Level1_Terminate
            Call GamePlay_Terminate
            Exit Sub
        End If
        
        
        DoEvents
        Call GamePlay_Init_Clock
        'Menu Loop
        Do
            If gbErrorFlag Then Exit Do
            Call GamePlay_Draw
            Call DirectInput_GetKeyboardState
            Call Level1_UpdateAndDraw(mgGame)
            Call DirectDraw_Flip
            Call GamePlay_Update_Clock
            Call GamePlay_CheckInput
        Loop While Not (mbQuit Or mgGame.bIsLevelComplete Or mgGame.bIsGameOver Or mgGame.bIsPlayerDead)
        mgGame.bIsPlayerDead = False
        If mgGame.iNumShips <= 0 Then mgGame.bIsGameOver = True
        DoEvents
        
        Call Level1_Terminate
    Loop While Not (mbQuit Or mgGame.bIsLevelComplete Or mgGame.bIsGameOver)
    
    Call GamePlay_Terminate
    Exit Sub
    
GamePlay_Start_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "GamePlay_Start"
    Call Level1_Terminate
    Call GamePlay_Terminate
End Sub

Private Sub GamePlay_Init_Clock()
    mlTicksPassed = 0
    mdFrames = 0
    mlTickCount = Win32.GetTickCount()
    mlFirstTickCount = mlTickCount
    mlLastTickCount = mlTickCount
End Sub

Private Sub GamePlay_Update_Clock()
    mdFrames = mdFrames + 1
    mlTickCount = Win32.GetTickCount()
    mlTicksPassed = mlTickCount - mlLastTickCount
    mgGame.lTicksPassed = mlTicksPassed
    mlLastTickCount = mlTickCount
    mdAvgFramesPerSecond = mdFrames * 1000 / (mlTickCount - mlFirstTickCount)
End Sub

Public Sub GamePlay_Initialize()
    mgGame.iPlayHeight = SCREENHEIGHT - 16
    mgGame.iPlayWidth = SCREENWIDTH
    mgGame.iPlayXOffset = 0
    mgGame.iPlayYOffset = 0
    mgGame.lTicksPassed = 0
    mgGame.lScore = 0
    mgGame.iNumShips = 3
    Set mgGame.ddDirectDraw = DirectDraw_Get()
    Set mgGame.ddsBackBufferSurface = DirectDraw_GetBackBufferSurface()
    mgGame.bIsGameOver = False
    mgGame.bIsLevelComplete = False

    'For clearing the back buffer
    With mddfxPaintBlack
        .dwSize = Len(mddfxPaintBlack)
        .dwFillColor = RGB(0, 0, 0)
    End With

    'For drawing horizontal line on screen
    mlHPen = CreatePen(PS_SOLID, 1, RGB(0, 0, 255))

End Sub

Public Sub GamePlay_Terminate()
    Set mgGame.ddsBackBufferSurface = Nothing
    Set mgGame.ddDirectDraw = Nothing

    'For drawing horizontal line on screen
    DeleteObject mlHPen

End Sub

Public Sub GamePlay_CheckInput()
    If DirectInput_IsKeyDown(Directx.DIK_ESCAPE) Then
        mbQuit = True
    End If
End Sub

Public Function GamePlay_Draw() As Boolean
    Dim lsMsg As String
    Dim lMsgSize As Size
    Dim llHdc As Long
    
    'Paint entire back buffer black (clear it!)
    mgGame.ddsBackBufferSurface.Blt ByVal 0&, Nothing, ByVal 0&, _
            DDBLT_COLORFILL Or DDBLT_WAIT, mddfxPaintBlack
    
    'Lock a DC for drawing and text operations
    Call mgGame.ddsBackBufferSurface.GetDC(llHdc)
    
    'Draw a horizontal line near the bottom of the screen
    SelectObject llHdc, mlHPen
    MoveToEx llHdc, 0, mgGame.iPlayHeight, ByVal 0&
    LineTo llHdc, mgGame.iPlayWidth, mgGame.iPlayHeight
    
    'Show mdFrames per Second ===== TEMPORARY ======
    If (mlTicksPassed > 0) Then
        lsMsg = Format$(mdAvgFramesPerSecond, "0.0") & "/" & Format$(1000 / mlTicksPassed, "0.0")
    Else
        lsMsg = ""
    End If
    
    'Show SCORE
    lsMsg = lsMsg & Format$(mgGame.lScore, "00000")
    
    'Paint SCORE
    Call SetBkColor(llHdc, RGB(0, 0, 0))
    Call SetTextColor(llHdc, RGB(255, 255, 0))
    Call GetTextExtentPoint32(llHdc, lsMsg, Len(lsMsg), lMsgSize)
    Call TextOut(llHdc, SCREENWIDTH - lMsgSize.cx - 1, SCREENHEIGHT - lMsgSize.cy - 1, lsMsg, Len(lsMsg))
    
    'Paint NUMBER OF SHIPS
    lsMsg = "X" & mgGame.iNumShips
    Call GetTextExtentPoint32(llHdc, lsMsg, Len(lsMsg), lMsgSize)
    Call TextOut(llHdc, 0, SCREENHEIGHT - lMsgSize.cy - 1, lsMsg, Len(lsMsg))
    
    'Release DC
    Call mgGame.ddsBackBufferSurface.ReleaseDC(llHdc)
End Function
