Attribute VB_Name = "modDirectDraw"
Option Explicit

'DirectDraw Object
Global gDirectDraw As IDirectDraw2
'Front and Back Surface, for double Buffering
Private mDDSFront As IDirectDrawSurface2
Global gDDSBack As IDirectDrawSurface2
'Host form
Private mFormHost As Form

Public Function DirectDraw_Initialize() As Boolean
    On Error GoTo DirectDraw_Initialize_ErrorHandler
        
    DirectDrawCreate ByVal 0&, gDirectDraw, Nothing
    DirectDraw_Initialize = True
    Exit Function
        
DirectDraw_Initialize_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "DirectDraw_Initialize"
    DirectDraw_Initialize = False
End Function

Public Sub DirectDraw_Terminate()
    On Error Resume Next
    
    If Not (gDirectDraw Is Nothing) Then
        'Flip from gDirectDraw-Surface to standard GDI
        gDirectDraw.FlipToGDISurface
        'Restore old resolution and depth
        gDirectDraw.RestoreDisplayMode
        'Return control to windows
        gDirectDraw.SetCooperativeLevel mFormHost.hWnd, DDSCL_NORMAL
    End If
    
    Set gDDSBack = Nothing
    Set mDDSFront = Nothing
    Set gDirectDraw = Nothing
    Set mFormHost = Nothing

    On Error GoTo 0
End Sub

Public Function DirectDraw_SetCooperativeLevel(rForm As Form, rlLevel As Long) As Boolean
    On Error GoTo DirectDraw_SetCooperativeLevel_ErrorHandler
    Set mFormHost = rForm
    gDirectDraw.SetCooperativeLevel mFormHost.hWnd, rlLevel
    DirectDraw_SetCooperativeLevel = True
    Exit Function
    
DirectDraw_SetCooperativeLevel_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "DirectDraw_SetCooperativeLevel"
    DirectDraw_SetCooperativeLevel = False
End Function

Public Function DirectDraw_SetDisplayMode(riWidth As Integer, riHeight As Integer, riDepth As Integer) As Boolean
    On Error GoTo DirectDraw_SetDisplayMode_ErrorHandler
     gDirectDraw.SetDisplayMode riWidth, riHeight, riDepth, 0, 0
    DirectDraw_SetDisplayMode = True
    Exit Function

DirectDraw_SetDisplayMode_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "DirectDraw_SetDisplayMode"
    DirectDraw_SetDisplayMode = False
End Function

Public Function DirectDraw_CreateFlippingBuffers() As Boolean
    On Error GoTo DirectDraw_CreateFlippingBuffers_ErrorHandler
    
    'Description of DirectDraw Surface
    Dim lDDSurfaceDescFront As DDSURFACEDESC
    'Display capabilities
    Dim lDDSCapsBack As DDSCAPS
    
    ' Initialize front buffer description
    With lDDSurfaceDescFront
        ' Get Structure size
        .dwSize = Len(lDDSurfaceDescFront)
        ' Structure uses Surface Caps and count of BackBuffers
        .dwFlags = DDSD_CAPS Or DDSD_BACKBUFFERCOUNT
        ' Structure describes a flippable (buffered) surface
        .DDSCAPS.dwCaps = DDSCAPS_PRIMARYSURFACE Or DDSCAPS_FLIP Or DDSCAPS_COMPLEX Or DDSCAPS_SYSTEMMEMORY
        '         ' Structure uses one BackBuffer
        '         .dwBackBufferCount = 1
        ' Structure uses two BackBuffers
        .dwBackBufferCount = 2
    End With
    
    ' Create front buffer from structure
    gDirectDraw.CreateSurface lDDSurfaceDescFront, mDDSFront, Nothing
    
    ' Create back buffer from front buffer
    lDDSCapsBack.dwCaps = DDSCAPS_BACKBUFFER
    mDDSFront.GetAttachedSurface lDDSCapsBack, gDDSBack

    DirectDraw_CreateFlippingBuffers = True
    Exit Function

DirectDraw_CreateFlippingBuffers_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "DirectDraw_CreateFlippingBuffers"
    DirectDraw_CreateFlippingBuffers = False
End Function

Public Function DirectDraw_Get() As IDirectDraw2
    Set DirectDraw_Get = gDirectDraw
End Function

Public Function DirectDraw_GetBackBufferSurface() As IDirectDrawSurface2
    Set DirectDraw_GetBackBufferSurface = gDDSBack
End Function

Public Function DirectDraw_CreateSurfaceFromBitmapFile(rsFile) As IDirectDrawSurface2
    Set DirectDraw_CreateSurfaceFromBitmapFile = LoadBitmapIntoDXS(gDirectDraw, rsFile)
End Function

Public Function DirectDraw_Flip() As Boolean
    DirectDraw_Flip = True
    Dim llCount As Long
    llCount = 0
    On Error Resume Next
    Do
        mDDSFront.Flip Nothing, 0
        If Err.Number = DDERR_SURFACELOST Then
            llCount = llCount + 1
            If (llCount > 1000) Then
                HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "DirectDraw_Flip"
                DirectDraw_Flip = False
                Exit Do
            End If
            mDDSFront.Restore
        End If
    Loop Until Err.Number = 0
    On Error GoTo 0
End Function
