Attribute VB_Name = "modGame"
Option Explicit

Type Game
    ddDirectDraw As IDirectDraw2 'local copy - don't forget to Set to Nothing!
    ddsBackBufferSurface As IDirectDrawSurface2 'local copy - don't forget to Set to Nothing!
    lTicksPassed As Long
    iPlayHeight As Integer
    iPlayWidth As Integer
    iPlayXOffset As Integer
    iPlayYOffset As Integer
    iNumShips As Integer
    lScore As Long
    bIsGameOver As Boolean
    bIsPlayerDead As Boolean
    bIsLevelComplete As Boolean
End Type
