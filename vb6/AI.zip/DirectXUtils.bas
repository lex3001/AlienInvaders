Attribute VB_Name = "modDirectXUtils"
Option Explicit

Const LR_LOADFROMFILE = &H10
Const LR_CREATEDIBSECTION = &H2000
Private Declare Function GetObject Lib "gdi32" Alias "GetObjectA" (ByVal hObject As Long, ByVal nCount As Long, lpObject As Any) As Long
Private Declare Sub CopyMemory Lib "Kernel32" Alias "RtlMoveMemory" (ByVal Destination As Long, ByVal Source As Long, ByVal length As Long)

'
' DirectX Bitmap Loader
'
Public Function LoadBitmapIntoDXS(DXObject As IDirectDraw2, ByVal BMPFile As String) As IDirectDrawSurface2
    
    Dim hBitmap As Long                 ' Handle on bitmap
    Dim dBitmap As BITMAP               ' Handle on bitmap descriptor
    Dim TempDXD As DDSURFACEDESC        ' Surface description
    Dim TempDXS As IDirectDrawSurface2   ' Created surface
    Dim dcBitmap As Long                ' Handle on image
    Dim dcDXS As Long                   ' Handle on surface context
   
    ' Load bitmap
    hBitmap = LoadImage(ByVal 0&, BMPFile, 0, 0, 0, LR_LOADFROMFILE Or LR_CREATEDIBSECTION)
    ' Get bitmap descriptor
    GetObject hBitmap, Len(dBitmap), dBitmap
    
    ' Fill DX surface description
    With TempDXD
        .dwSize = Len(TempDXD)
        .dwFlags = DDSD_CAPS Or DDSD_HEIGHT Or DDSD_WIDTH
        .DDSCAPS.dwCaps = DDSCAPS_OFFSCREENPLAIN
        .dwWidth = dBitmap.bmWidth
        .dwHeight = dBitmap.bmHeight
    End With
    ' Create DX surface
    DXObject.CreateSurface TempDXD, TempDXS, Nothing
    
    ' Create API memory DC
    dcBitmap = CreateCompatibleDC(ByVal 0&)
    ' Select the bitmap into API memory DC
    SelectObject dcBitmap, hBitmap
    
    ' Restore DX surface
    TempDXS.Restore
    ' Get DX surface API DC
    TempDXS.GetDC dcDXS
    ' Blit BMP from API DC into DX DC using standard API BitBlt
    StretchBlt dcDXS, 0, 0, TempDXD.dwWidth, TempDXD.dwHeight, dcBitmap, 0, 0, dBitmap.bmWidth, dBitmap.bmHeight, SRCCOPY
    
    ' Cleanup
    TempDXS.ReleaseDC dcDXS
    DeleteDC dcBitmap
    DeleteObject hBitmap
    
    ' Return created DX surface
    Set LoadBitmapIntoDXS = TempDXS
    
End Function


'
' Loads a Wave file into a direct sound buffer
'
Public Sub LoadWAVIntoDSB(Lds As IDirectSound, ByVal fName As String, Ldsb As IDirectSoundBuffer)
    
    Dim hWave As Long
    Dim pcmwave As WAVEFORMATEX
    Dim lngSize As Long
    Dim lngPosition As Long
    Dim ptr1 As Long, ptr2 As Long, lng1 As Long, lng2 As Long
    Dim aByte() As Byte
    
    ReDim aByte(1 To FileLen(fName))
    hWave = FreeFile
    Open fName For Binary As hWave
    Get hWave, , aByte
    Close hWave
    lngPosition = 1
    While Chr$(aByte(lngPosition)) + Chr$(aByte(lngPosition + 1)) + Chr$(aByte(lngPosition + 2)) <> "fmt"
        lngPosition = lngPosition + 1
    Wend
    CopyMemory VarPtr(pcmwave), VarPtr(aByte(lngPosition + 8)), Len(pcmwave)
    While Chr$(aByte(lngPosition)) + Chr$(aByte(lngPosition + 1)) + Chr$(aByte(lngPosition + 2)) + Chr$(aByte(lngPosition + 3)) <> "data"
        lngPosition = lngPosition + 1
    Wend
    CopyMemory VarPtr(lngSize), VarPtr(aByte(lngPosition + 4)), Len(lngSize)
    Dim dsbd As DSBUFFERDESC
    With dsbd
        .dwSize = Len(dsbd)
        .dwFlags = DSBCAPS_CTRLDEFAULT
        .dwBufferBytes = lngSize
        .lpwfxFormat = VarPtr(pcmwave)
    End With
    Lds.CreateSoundBuffer dsbd, Ldsb, Nothing
    Ldsb.Lock 0&, lngSize, ptr1, lng1, ptr2, lng2, 0&
    CopyMemory ptr1, VarPtr(aByte(lngPosition + 4 + 4)), lng1
    If lng2 <> 0 Then
        CopyMemory ptr2, VarPtr(aByte(lngPosition + 4 + 4 + lng1)), lng2
    End If
    
End Sub
