Attribute VB_Name = "modLevel1"
Option Explicit

'Direct draw resources for animation bitmaps
Dim mddsAlienA As IDirectDrawSurface2
Dim mddsAlienB As IDirectDrawSurface2
Dim mddsAlienABomb As IDirectDrawSurface2
Dim mddsPlayer As IDirectDrawSurface2
Dim mddsMissle As IDirectDrawSurface2

Dim miHseMissle As Integer
Dim miHseExplosion As Integer

'Player guns
Dim mpgPlayerGuns As PlayerGuns

'Actors
Dim maPlayer As Actor
Dim maMissles() As Actor
Dim maAliensA() As Actor
Dim maAliensB() As Actor
Dim maAlienABombs() As Actor
Const miMAX_ALIENA_BOMBS% = 25
Const mlALIENA_BOMB_INTERVAL& = 4000 'each AlienA drops a bomb avg every 5 sec.

Dim miNumMissles As Integer
Dim miNumAlienABombs As Integer
Dim miNumAliensA As Integer
Dim miMaxAliensA As Integer
Dim miNumAliensB As Integer
Dim miMaxAliensB As Integer

Dim mbMissleRequested As Boolean
Dim mbShieldsRequested As Boolean
Dim mbShieldsOn As Boolean

Public Sub Level1_UpdateAndDraw(rgGame As Game)
    Call Level1_CheckInput
    Call Level1_HandleMissles(rgGame)
    Call Level1_HandleAlienABombs(rgGame)
    Call Level1_HandleAliensA(rgGame)
    Call Level1_HandleAliensB(rgGame)
    Call Level1_HandlePlayer(rgGame)
    
    If (miNumAliensA <= 0) And (miNumAliensB <= 0) Then
        rgGame.bIsLevelComplete = True
    End If
End Sub

Private Sub Level1_HandleMissles(rgGame As Game)
    On Error GoTo Level1_HandleMissles_ErrorHandler
    
    'update state of player's guns
    Call PlayerGuns_UpdateState(mpgPlayerGuns, rgGame)
    
    'see if we should launch a missle
    If (mbMissleRequested) And (mpgPlayerGuns.bShotReady) Then
        mpgPlayerGuns.bShotReady = False
        If (miNumMissles < mpgPlayerGuns.iMaxOnScreen) Then
            miNumMissles = miNumMissles + 1
            With maMissles(miNumMissles).amMover
                .iX = maPlayer.amMover.iX + (maPlayer.iXSize / 2) - 1
                .iY = maPlayer.amMover.iY - 8
            End With
            
            Call DirectSound_PlaySoundEffect(miHseMissle, 0&, _
                    Actor_GetPan(maMissles(miNumMissles), rgGame))
'            Call DirectSound_PlaySoundEffect(miHseMissle)
            'PLAY SOUND!
            
        End If
    End If

    'Draw Missles then Update
    Dim liMissleIdx As Integer
    
    liMissleIdx = 1
    Do While (liMissleIdx <= miNumMissles)
        Call ActorDrawer_Draw(maMissles(liMissleIdx), rgGame)
        Call ActorMover_Move(maMissles(liMissleIdx), rgGame)
        
        If (maMissles(liMissleIdx).amMover.bIsOffScreen) Then
            If (liMissleIdx < miNumMissles) Then
                'move last entry to this entry to delete this one then shorten array by one
                maMissles(liMissleIdx) = maMissles(miNumMissles)
            End If
'            Set maMissles(miNumMissles) = Nothing
            miNumMissles = miNumMissles - 1
        Else
            liMissleIdx = liMissleIdx + 1
        End If
    Loop
        
    Exit Sub
    
Level1_HandleMissles_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_HandleMissles"
End Sub

Private Sub Level1_HandlePlayer(rgGame As Game)
    On Error GoTo Level1_HandlePlayer_ErrorHandler
    
    'Draw Player
    If Not (mbShieldsRequested = mbShieldsOn) Then
        mbShieldsOn = mbShieldsRequested
        If mbShieldsOn Then
            maPlayer.adDrawer.iCurrentFrameInSequence = 0
            maPlayer.adDrawer.iNumFrames = 4
            maPlayer.adDrawer.iStartFrame = 4
        Else
            maPlayer.adDrawer.iCurrentFrameInSequence = 0
            maPlayer.adDrawer.iNumFrames = 1
            maPlayer.adDrawer.iStartFrame = 0
        End If
    End If
    Call ActorDrawer_Draw(maPlayer, rgGame)

    'See if an exploding alien is done exploding
    If maPlayer.bExploding And _
            maPlayer.adDrawer.bIsAnimationDone Then
        rgGame.bIsPlayerDead = True
    Else
        'Move Player
        Call ActorMover_Move(maPlayer, rgGame)
    End If
        
    Exit Sub
    
Level1_HandlePlayer_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_HandlePlayer"
End Sub

Private Sub Level1_HandleAliensA(rgGame As Game)
    On Error GoTo Level1_HandleAliensA_ErrorHandler
    
    Dim liAlienIdx As Integer
    Dim liMisslesIdx As Integer
    
    'Draw BadGuys then Update
    liAlienIdx = 1
    Do While (liAlienIdx <= miNumAliensA)
        'Draw Alien
        Call ActorDrawer_Draw(maAliensA(liAlienIdx), rgGame)
        
        'If this alien is not exploding...
        If (Not maAliensA(liAlienIdx).bExploding) Then
            'See if it should drop a bomb
            If Rnd < (rgGame.lTicksPassed / mlALIENA_BOMB_INTERVAL&) Then
                Call Level1_DropAlienABomb(maAliensA(liAlienIdx), rgGame)
            End If
        
            'See if it hit a missle
            liMisslesIdx = 1
            Do While (liMisslesIdx <= miNumMissles)
                If Actor_DetectCollision(maAliensA(liAlienIdx), maMissles(liMisslesIdx)) Then
                    'BANG!
                    Call DirectSound_PlaySoundEffect(miHseExplosion, 0&, _
                            Actor_GetPan(maAliensA(liAlienIdx), rgGame))
                    
                    'Get rid of the missle
                    If (liMisslesIdx < miNumMissles) Then
                        'move last entry to this entry to delete this one then shorten array by one
                        maMissles(liMisslesIdx) = maMissles(miNumMissles)
                    End If
                    miNumMissles = miNumMissles - 1
                    
                    'Update the score
                    rgGame.lScore = rgGame.lScore + 10
                    
                    'Turn the alien into an explosion
                    maAliensA(liAlienIdx).bExploding = True
                    With maAliensA(liAlienIdx).adDrawer
                        .iStartFrame = 20
                        .iNumFrames = 8
                        .iFramesPerSecond = -1 'use TicksPerFrame
                        .iTicksPerFrame = 1
                        .iCurrentFrameInSequence = 0
                        .bLoopAnimation = False
                    End With
                    
                    'collision- don't check any more missles
                    Exit Do
                End If
                liMisslesIdx = liMisslesIdx + 1
            Loop 'missles
        End If

        'See if an exploding alien is done exploding
        If maAliensA(liAlienIdx).bExploding And _
                maAliensA(liAlienIdx).adDrawer.bIsAnimationDone Then
            'get rid of it
            If (liAlienIdx < miNumAliensA) Then
                'move last entry to this entry to delete this one then shorten array by one
                maAliensA(liAlienIdx) = maAliensA(miNumAliensA)
            End If
            miNumAliensA = miNumAliensA - 1
        Else
            'Update Alien Position
            Call ActorMover_Move(maAliensA(liAlienIdx), rgGame)
            liAlienIdx = liAlienIdx + 1
        End If
        
    Loop 'aliens
        
    Exit Sub
    
Level1_HandleAliensA_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_HandleAliensA"
End Sub

Private Sub Level1_HandleAliensB(rgGame As Game)
    On Error GoTo Level1_HandleAliensB_ErrorHandler
    
    Dim liAlienIdx As Integer
    Dim liMisslesIdx As Integer
    
    'Draw BadGuys then Update
    liAlienIdx = 1
    Do While (liAlienIdx <= miNumAliensB)
        'Draw Alien
        Call ActorDrawer_Draw(maAliensB(liAlienIdx), rgGame)
        
        'If this alien is not exploding...
        If (Not maAliensB(liAlienIdx).bExploding) Then
'            'See if it should drop a bomb
'            If Rnd < (rgGame.lTicksPassed / mlALIENA_BOMB_INTERVAL&) Then
'                Call Level1_DropAlienABomb(maAliensB(liAlienIdx), rgGame)
'            End If
        
            'See if it hit a missle
            liMisslesIdx = 1
            Do While (liMisslesIdx <= miNumMissles)
                If Actor_DetectCollision(maAliensB(liAlienIdx), maMissles(liMisslesIdx)) Then
                    'BANG!
                    Call DirectSound_PlaySoundEffect(miHseExplosion, 0&, _
                            Actor_GetPan(maAliensB(liAlienIdx), rgGame))
                    
                    'Get rid of the missle
                    If (liMisslesIdx < miNumMissles) Then
                        'move last entry to this entry to delete this one then shorten array by one
                        maMissles(liMisslesIdx) = maMissles(miNumMissles)
                    End If
                    miNumMissles = miNumMissles - 1
                    
                    
'================================
                    With maAliensB(liAlienIdx)
                        .iState = .iState + 1
                        If .iState > 3 Then
                            'Turn the alien into an explosion
                            maAliensB(liAlienIdx).bExploding = True
                            With .adDrawer
                                .iStartFrame = 56
                                .iNumFrames = 8
                                .iFramesPerSecond = -1 'use TicksPerFrame
                                .iTicksPerFrame = 1
                                .iCurrentFrameInSequence = 0
                                .bLoopAnimation = False
                            End With
                            'Update the score
                            rgGame.lScore = rgGame.lScore + 5
                        Else
                            'Transition alien to next state
                            With .adDrawer
                                .bAutoSwitchToNextSequence = True
                                .iStartFrame = ((maAliensB(liAlienIdx).iState * 2) - 1) * 8
                                .iNumFrames = 8
                                .iNextStartFrame = (maAliensB(liAlienIdx).iState * 2) * 8
                                .iNextNumFrames = 8
                                .iCurrentFrameInSequence = 0
                                .bLoopAnimation = True
                            End With
                            'Update the score
                            rgGame.lScore = rgGame.lScore + 10
                        End If
                    End With
                    
                    'collision- don't check any more missles
                    Exit Do
                End If
                
                liMisslesIdx = liMisslesIdx + 1
            Loop 'missles
        End If

        'See if an exploding alien is done exploding
        If maAliensB(liAlienIdx).bExploding And _
                maAliensB(liAlienIdx).adDrawer.bIsAnimationDone Then
            'get rid of it
            If (liAlienIdx < miNumAliensB) Then
                'move last entry to this entry to delete this one then shorten array by one
                maAliensB(liAlienIdx) = maAliensB(miNumAliensB)
            End If
            miNumAliensB = miNumAliensB - 1
        Else
            'Update Alien Position
            Call ActorMover_Move(maAliensB(liAlienIdx), rgGame)
            liAlienIdx = liAlienIdx + 1
        End If
        
    Loop 'aliens
        
    Exit Sub
    
Level1_HandleAliensB_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_HandleAliensB"
End Sub

Private Sub Level1_HandleAlienABombs(rgGame As Game)
    On Error GoTo Level1_HandleAlienABombs_ErrorHandler
    
    'Draw AlienABombs then Update
    Dim liBombIdx As Integer
    Dim lbRemoveBomb As Boolean
    
    liBombIdx = 1
    Do While (liBombIdx <= miNumAlienABombs)
        Call ActorDrawer_Draw(maAlienABombs(liBombIdx), rgGame)
        Call ActorMover_Move(maAlienABombs(liBombIdx), rgGame)
        
        lbRemoveBomb = False
        If (maAlienABombs(liBombIdx).amMover.bIsOffScreen) Then
            lbRemoveBomb = True
        ElseIf Not maPlayer.bExploding And _
                (Actor_DetectCollision(maAlienABombs(liBombIdx), maPlayer)) Then
            lbRemoveBomb = True
            If Not mbShieldsOn Then
                'BANG!
                Call DirectSound_PlaySoundEffect(miHseExplosion, 0&, _
                        Actor_GetPan(maPlayer, rgGame))
                
                'Get rid of the bomb
                If (liBombIdx < miNumAlienABombs) Then
                    'move last entry to this entry to delete this one then shorten array by one
                    maAlienABombs(liBombIdx) = maAlienABombs(miNumAlienABombs)
                End If
                miNumAlienABombs = miNumAlienABombs - 1
                
                'Turn the player into an explosion
                maPlayer.bExploding = True
                maPlayer.amMover.iVelocity = 0
                With maPlayer.adDrawer
                    .iStartFrame = 8
                    .iNumFrames = 24
                    .iFramesPerSecond = -1 'use TicksPerFrame
                    .iTicksPerFrame = 1
                    .iCurrentFrameInSequence = 0
                    .bLoopAnimation = False
                End With
                
                'Play Boom
                'Do some other stuff
                rgGame.iNumShips = rgGame.iNumShips - 1
                
                'etc...
                'collision- don't check any more missles
                Exit Do
            Else
                'Play another sound
            End If
        End If

        If lbRemoveBomb Then
            If (liBombIdx < miNumAlienABombs) Then
                'move last entry to this entry to delete this one then shorten array by one
                maAlienABombs(liBombIdx) = maAlienABombs(miNumAlienABombs)
            End If
'            Set maAlienABombs(miNumAlienABombs) = Nothing
            miNumAlienABombs = miNumAlienABombs - 1
        Else
            liBombIdx = liBombIdx + 1
        End If
    Loop
        
    Exit Sub
    
Level1_HandleAlienABombs_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_HandleAlienABombs"
End Sub

Private Sub Level1_DropAlienABomb(raAlienA As Actor, rgGame As Game)
    On Error GoTo Level1_DropAlienABomb_ErrorHandler
    
    If (miNumAlienABombs < miMAX_ALIENA_BOMBS%) Then
        miNumAlienABombs = miNumAlienABombs + 1
        With maAlienABombs(miNumAlienABombs).amMover
            .iX = raAlienA.amMover.iX + (raAlienA.iXSize / 2) - 1
            .iY = raAlienA.amMover.iY + raAlienA.iYSize
        End With
        
'        Call DirectSound_PlaySoundEffect(miHseMissle, 0&, _
                Actor_GetPan(maAlienABombs(miNumAlienABombs), rgGame))
    End If

    Exit Sub
    
Level1_DropAlienABomb_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_DropAlienABomb"
End Sub

Public Function Level1_Initialize(rgGame As Game) As Boolean
    On Error GoTo Level1_Initialize_ErrorHandler
    Level1_Initialize = False
    
    Set mddsAlienA = LoadBitmapIntoDXS(rgGame.ddDirectDraw, _
            App.Path + "\Resource\AlienA.bmp")
    Set mddsAlienB = LoadBitmapIntoDXS(rgGame.ddDirectDraw, _
            App.Path + "\Resource\AlienB.bmp")
    Set mddsAlienABomb = LoadBitmapIntoDXS(rgGame.ddDirectDraw, _
            App.Path + "\Resource\AlienABomb.bmp")
    Set mddsPlayer = LoadBitmapIntoDXS(rgGame.ddDirectDraw, _
            App.Path + "\Resource\Ship.bmp")
    Set mddsMissle = LoadBitmapIntoDXS(rgGame.ddDirectDraw, _
            App.Path + "\Resource\Missle.bmp")
    
    If Not DirectSound_LoadSoundEffect(miHseMissle, _
            App.Path + "\Resource\Laser.wav", 1) Then Exit Function
    If Not DirectSound_LoadSoundEffect(miHseExplosion, _
            App.Path + "\Resource\Whoosh.wav", 5) Then Exit Function
    
    If Not Level1_Init_Player(rgGame) Then Exit Function
    If Not Level1_Init_AliensA(rgGame) Then Exit Function
    If Not Level1_Init_AliensB(rgGame) Then Exit Function
    If Not Level1_Init_Missles(rgGame) Then Exit Function
    If Not Level1_Init_AlienABombs(rgGame) Then Exit Function
    
    Level1_Initialize = True
    
    Exit Function
        
Level1_Initialize_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Initialize"
End Function

Public Sub Level1_Terminate()
    On Error Resume Next
    
    Dim liIdx As Integer
    
    Set mddsAlienA = Nothing
    Set mddsAlienB = Nothing
    Set mddsAlienABomb = Nothing
    Set mddsPlayer = Nothing
    Set mddsMissle = Nothing

    Call DirectSound_ReleaseSoundEffect(miHseMissle)
    Call DirectSound_ReleaseSoundEffect(miHseExplosion)

    Set maPlayer.adDrawer.ddsBitMapSurface = Nothing
    
    For liIdx = 1 To giMAX_MISSLES%
        Set maMissles(liIdx).adDrawer.ddsBitMapSurface = Nothing
    Next
    Erase maMissles()
    
    For liIdx = 1 To miMAX_ALIENA_BOMBS%
        Set maAlienABombs(liIdx).adDrawer.ddsBitMapSurface = Nothing
    Next
    Erase maAlienABombs()
    
    For liIdx = 1 To miMaxAliensA
        Set maAliensA(liIdx).adDrawer.ddsBitMapSurface = Nothing
    Next
    Erase maAliensA()
    
    For liIdx = 1 To miMaxAliensB
        Set maAliensB(liIdx).adDrawer.ddsBitMapSurface = Nothing
    Next
    Erase maAliensB()
    
    On Error GoTo 0
End Sub

Private Function Level1_Init_Player(rgGame As Game) As Boolean
    On Error GoTo Level1_Init_Player_ErrorHandler
    
    Dim ladDrawer As ActorDrawer

    With maPlayer
        .iXSize = 26
        .iYSize = 18
        .iXCollisionBoxOffset = 1
        .iXCollisionBoxSize = 24
        .iYCollisionBoxOffset = 8
        .iYCollisionBoxSize = 16
        .bExploding = False
    End With
    
    With maPlayer.adDrawer
        Set .ddsBitMapSurface = mddsPlayer
        .bAutoSwitchToNextSequence = False
        .iFrameSizeX = 32
        .iFrameSizeY = 18
        .iWidthInFrames = 4
        .iStartFrame = 0
        .iNumFrames = 1
        .iFramesPerSecond = -1 'use TicksPerFrame
        .iTicksPerFrame = 3
        .bLoopAnimation = True
    End With
        
    With maPlayer.amMover
        .iMarchingDistance = giDONT_MARCH
        .iDirection = 0
        .iVelocity = 0 '120 Pix/Sec is about 4 seconds to go accross screen
        .iX = (rgGame.iPlayWidth / 2) - (maPlayer.iXSize / 2)
        .iY = rgGame.iPlayHeight - (maPlayer.iYSize + 1)
        .bReverseAtBorder = False
        .bStopAtBorder = True
    End With
    
    mbShieldsOn = False
    
    With mpgPlayerGuns
        .bShotReady = True
        .iMaxOnScreen = 2
        .lRechargeTime = 500
        .lTicksSinceLastShot = 0
    End With
    
    Level1_Init_Player = True
    Exit Function
    
Level1_Init_Player_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Init_Player"
    Level1_Init_Player = False
End Function


Private Function Level1_Init_Missles(rgGame As Game) As Boolean
    On Error GoTo Level1_Init_Missles_ErrorHandler
    
    Dim liCtr As Integer
    ReDim maMissles(1 To giMAX_MISSLES%)
    miNumMissles = 0
    mbMissleRequested = False

    'Initialize everything except for position
    For liCtr = 1 To giMAX_MISSLES%
        With maMissles(liCtr)
            .iXSize = 2
            .iYSize = 16
            .iXCollisionBoxOffset = 0
            .iXCollisionBoxSize = 2
            .iYCollisionBoxOffset = 0
            .iYCollisionBoxSize = 16
        End With
        With maMissles(liCtr).adDrawer
            Set .ddsBitMapSurface = mddsMissle
            .bAutoSwitchToNextSequence = False
            .iFrameSizeX = 2
            .iFrameSizeY = 16
            .iWidthInFrames = 1
            .iStartFrame = 0
            .iNumFrames = 1
            .iFramesPerSecond = -1 'use TicksPerFrame
            .iTicksPerFrame = 1
            .bLoopAnimation = True
        End With
        With maMissles(liCtr).amMover
            .iDirection = 270
            .iVelocity = 200 '120 Pix/Sec is about 4 seconds to go accross screen
'            .iX = APlayer.iX + (APlayer.XSize / 2) - 1
'            .iY = APlayer.iY - 8
            .bReverseAtBorder = False
            .bStopAtBorder = False
        End With
    Next liCtr

    Level1_Init_Missles = True
    Exit Function
    
Level1_Init_Missles_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Init_Missles"
    Level1_Init_Missles = False
End Function

Private Function Level1_Init_AlienABombs(rgGame As Game) As Boolean
    On Error GoTo Level1_Init_AlienABombs_ErrorHandler
    
    Dim liCtr As Integer
    ReDim maAlienABombs(1 To miMAX_ALIENA_BOMBS%)
    miNumAlienABombs = 0

    'Initialize everything except for position
    For liCtr = 1 To miMAX_ALIENA_BOMBS%
        With maAlienABombs(liCtr)
            .iXSize = 2
            .iYSize = 8
            .iXCollisionBoxOffset = 0
            .iXCollisionBoxSize = 2
            .iYCollisionBoxOffset = 0
            .iYCollisionBoxSize = 8
        End With
        With maAlienABombs(liCtr).adDrawer
            Set .ddsBitMapSurface = mddsAlienABomb
            .bAutoSwitchToNextSequence = False
            .iFrameSizeX = 2
            .iFrameSizeY = 8
            .iWidthInFrames = 1
            .iStartFrame = 0
            .iNumFrames = 1
            .iFramesPerSecond = -1 'use TicksPerFrame
            .iTicksPerFrame = 1
            .bLoopAnimation = True
        End With
        With maAlienABombs(liCtr).amMover
            .iDirection = 90
            .iVelocity = 80 '120 Pix/Sec is about 4 seconds to go accross screen
'            .iX = APlayer.iX + (APlayer.XSize / 2) - 1
'            .iY = APlayer.iY - 8
            .bReverseAtBorder = False
            .bStopAtBorder = False
        End With
    Next liCtr

    Level1_Init_AlienABombs = True
    Exit Function
    
Level1_Init_AlienABombs_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Init_AlienABombs"
    Level1_Init_AlienABombs = False
End Function

Private Function Level1_Init_AliensA(rgGame As Game) As Boolean
    On Error GoTo Level1_Init_AliensA_ErrorHandler
    
    Dim liCtrX As Integer
    Dim liCtrY As Integer
    Dim liNumAliensX As Integer
    Dim liNumAliensY As Integer
    Dim liAlienAIdx As Integer
    Dim liWidthPerAlien As Integer
    Dim liHeightPerAlien As Integer
    Dim liInsetX  As Integer
    Dim liXSize As Integer
    Dim liYSize As Integer
    
    liXSize = 23
    liYSize = 8
    liNumAliensX = 12
    liNumAliensY = 1
    liInsetX = 32
'    liWidthPerAlien = rgGame.iPlayWidth / liNumAliensX
    liWidthPerAlien = 32
    liHeightPerAlien = (rgGame.iPlayHeight) / liNumAliensY
    miMaxAliensA = liNumAliensX * liNumAliensY
    miNumAliensA = miMaxAliensA
    
    ReDim maAliensA(1 To miNumAliensA)
    
    For liCtrX = 1 To liNumAliensX
        For liCtrY = 1 To liNumAliensY
            liAlienAIdx = (liCtrY - 1) * liNumAliensX + liCtrX
            With maAliensA(liAlienAIdx)
                .iXSize = liXSize
                .iYSize = liYSize
                .iXCollisionBoxOffset = 0
                .iXCollisionBoxSize = liXSize
                .iYCollisionBoxOffset = 2
                .iYCollisionBoxSize = liYSize - 4
            End With
            With maAliensA(liAlienAIdx).adDrawer
                Set .ddsBitMapSurface = mddsAlienA
                .bAutoSwitchToNextSequence = False
                .iFrameSizeX = 32
                .iFrameSizeY = 8
                .iWidthInFrames = 4
                .iStartFrame = 0
                .iNumFrames = 20
                .iFramesPerSecond = -1 'use TicksPerFrame
                .iTicksPerFrame = 1
                .iCurrentFrameInSequence = Int(20 * Rnd)
                .bLoopAnimation = True
            End With
            With maAliensA(liAlienAIdx).amMover
                .iDirection = 0
                .iVelocity = 30 '160 Pix/Sec is about 4 seconds to go accross screen
'                .iX = liWidthPerAlien * (liCtrX - 1) + (liWidthPerAlien / 2) - (liXSize / 2)
                .iX = liWidthPerAlien * (liCtrX - 1) + ((liWidthPerAlien - liXSize) / 2)
                .iY = liHeightPerAlien * (liCtrY - 1) + (liHeightPerAlien / 2) - (liYSize / 2) - 24
                .bReverseAtBorder = False
                .bStopAtBorder = True
'                .iMarchingDistance = (liWidthPerAlien - liXSize)
                .iMarchingDistance = rgGame.iPlayWidth - (liNumAliensX * liWidthPerAlien) - 32
                If (.iX < 0) Then .iX = 0
                If (.iX + liXSize) > rgGame.iPlayWidth Then .iX = rgGame.iPlayWidth - liXSize
                If (.iY < 0) Then .iY = 0
                If (.iY + liYSize) > rgGame.iPlayHeight Then .iY = rgGame.iPlayHeight - liYSize
            End With
        Next
    Next

    Level1_Init_AliensA = True
    Exit Function
    
Level1_Init_AliensA_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Init_AliensA"
    Level1_Init_AliensA = False
End Function

Private Function Level1_Init_AliensB(rgGame As Game) As Boolean
    On Error GoTo Level1_Init_AliensB_ErrorHandler
    
    Dim liCtrX As Integer
    Dim liCtrY As Integer
    Dim liNumAliensX As Integer
    Dim liNumAliensY As Integer
    Dim liAlienAIdx As Integer
    Dim liWidthPerAlien As Integer
    Dim liHeightPerAlien As Integer
    Dim liInsetX  As Integer
    Dim liXSize As Integer
    Dim liYSize As Integer
    
    liXSize = 16
    liYSize = 16
    liNumAliensX = 12
    liNumAliensY = 1
    liInsetX = 32
'    liWidthPerAlien = rgGame.iPlayWidth / liNumAliensX
    liWidthPerAlien = 32
    liHeightPerAlien = (rgGame.iPlayHeight) / liNumAliensY
    miMaxAliensB = liNumAliensX * liNumAliensY
    miNumAliensB = miMaxAliensB
    
    ReDim maAliensB(1 To miNumAliensB)
    
    For liCtrX = 1 To liNumAliensX
        For liCtrY = 1 To liNumAliensY
            liAlienAIdx = (liCtrY - 1) * liNumAliensX + liCtrX
            With maAliensB(liAlienAIdx)
                .iXSize = liXSize
                .iYSize = liYSize
                .iXCollisionBoxOffset = 0
                .iXCollisionBoxSize = liXSize
                .iYCollisionBoxOffset = 0
                .iYCollisionBoxSize = liYSize - 7
                .iState = 0
            End With
            With maAliensB(liAlienAIdx).adDrawer
                Set .ddsBitMapSurface = mddsAlienB
                .bAutoSwitchToNextSequence = False
                .iFrameSizeX = 16
                .iFrameSizeY = 16
                .iWidthInFrames = 8
                .iStartFrame = 0
                .iNumFrames = 8
                .iFramesPerSecond = -1 'use TicksPerFrame
                .iTicksPerFrame = 1
                .iCurrentFrameInSequence = Int(8 * Rnd)
                .bLoopAnimation = True
            End With
            With maAliensB(liAlienAIdx).amMover
                .iDirection = 0
                .iVelocity = 30 '160 Pix/Sec is about 4 seconds to go accross screen
'                .iX = liWidthPerAlien * (liCtrX - 1) + (liWidthPerAlien / 2) - (liXSize / 2)
                .iX = liWidthPerAlien * (liCtrX - 1) + ((liWidthPerAlien - liXSize) / 2)
                .iY = liHeightPerAlien * (liCtrY - 1) + (liHeightPerAlien / 2) - (liYSize / 2)
                .bReverseAtBorder = False
                .bStopAtBorder = True
'                .iMarchingDistance = (liWidthPerAlien - liXSize)
                .iMarchingDistance = rgGame.iPlayWidth - (liNumAliensX * liWidthPerAlien) - 32
                If (.iX < 0) Then .iX = 0
                If (.iX + liXSize) > rgGame.iPlayWidth Then .iX = rgGame.iPlayWidth - liXSize
                If (.iY < 0) Then .iY = 0
                If (.iY + liYSize) > rgGame.iPlayHeight Then .iY = rgGame.iPlayHeight - liYSize
            End With
        Next
    Next

    Level1_Init_AliensB = True
    Exit Function
    
Level1_Init_AliensB_ErrorHandler:
    HandleError Err.Number, Err.Description, Err.LastDllError, Err.Source, "Level1_Init_AliensB"
    Level1_Init_AliensB = False
End Function

Public Sub Level1_CheckInput()
    If Not maPlayer.bExploding Then
        mbMissleRequested = DirectInput_IsKeyDown(Directx.DIK_LSHIFT) Or _
                DirectInput_IsKeyDown(Directx.DIK_RSHIFT)
        mbShieldsRequested = DirectInput_IsKeyDown(Directx.DIK_LMENU) Or _
                DirectInput_IsKeyDown(Directx.DIK_RMENU)
        
        If DirectInput_IsKeyDown(Directx.DIK_SPACE) Then
            maPlayer.amMover.iVelocity = 0
        ElseIf DirectInput_IsKeyDown(Directx.DIK_LEFT) Then
            maPlayer.amMover.iDirection = 180
            maPlayer.amMover.iVelocity = 60
        ElseIf DirectInput_IsKeyDown(Directx.DIK_RIGHT) Then
            maPlayer.amMover.iDirection = 0
            maPlayer.amMover.iVelocity = 60
        End If
    Else
        mbMissleRequested = False
        mbShieldsOn = False
    End If
End Sub

