Attribute VB_Name = "modGameUtils"
Option Explicit

'For handling keyboard input
Private mbNewKeyPressed As Boolean
Private miLastKeyCode As Integer
Private miLastShift As Integer

'For Calculating X,Y from angles
Global Const gdPI = 3.14159265358979
Private miXInc() As Double
Private miYInc() As Double
Private mbInitialized As Boolean

'For log file
Private miLogFile As Integer
Private mbLogOpen As Boolean

Public Sub GameUtils_Initialize()
    mbNewKeyPressed = False
    
    Dim i As Double
    Dim radians As Double
    ReDim miXInc(0 To 359) As Double
    ReDim miYInc(0 To 359) As Double
    
    For i = 0# To 359# Step 1#
        radians = i * gdPI / 180#
        miXInc(i) = Cos(radians)
        miYInc(i) = Sin(radians)
    Next i
    
    mbInitialized = True
End Sub

Public Sub GameUtils_Terminate()
    Erase miXInc
    Erase miYInc
    mbInitialized = False
End Sub

Public Sub ReportKeyDown(riKeyCode As Integer, riShift As Integer)
    'see Form KeyDown event
    mbNewKeyPressed = True
    miLastKeyCode = riKeyCode
    miLastShift = riShift
    'hmmmm... not sure if I should be handling keyboard events like this
End Sub

Public Function isKeyDown() As Boolean
    isKeyDown = mbNewKeyPressed
    'hmmmm... not sure if I should be handling keyboard events like this
End Function

Public Sub GetKeyDown(riKeyCode As Integer, riShift As Integer)
    mbNewKeyPressed = False
    riKeyCode = miLastKeyCode
    riShift = miLastShift
    'hmmmm... not sure if I should be handling keyboard events like this
End Sub

Public Sub GetXYIncFromAngle(riAngle As Integer, rdXInc As Double, rdYInc As Double)
    If Not mbInitialized Then GameUtils_Initialize
    
    Dim liAngle As Integer
    liAngle = riAngle Mod 360
    rdXInc = miXInc(liAngle)
    rdYInc = miYInc(liAngle)
End Sub

Public Function MinOf(riInt1 As Integer, riInt2 As Integer) As Integer
    MinOf = IIf(riInt1 < riInt2, riInt1, riInt2)
End Function

Public Function DebugPrint(msg As String)
    If (Not mbLogOpen) Then
        miLogFile = FreeFile()
        Open App.Path & "\debug.log" For Append As #miLogFile
    End If
    Print #miLogFile, msg
    Close #miLogFile
End Function
